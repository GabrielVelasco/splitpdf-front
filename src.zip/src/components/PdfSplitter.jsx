import React, { useState } from 'react';
import {
  Container,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
} from '@mui/material';

// import '../style/PdfSlitter.css'; // Import the CSS file

function PDFSplitter() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [maxSize, setMaxSize] = useState(1); // Default maximum size in MB

  // Handle file selection
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  // Handle maximum size selection
  const handleMaxSizeChange = (event) => {
    setMaxSize(event.target.value);
  };

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();

    if (!selectedFile) {
      alert('Please select a PDF file to upload.');
      return;
    }

    // Prepare form data
    const formData = new FormData();
    formData.append('pdf_file', selectedFile);
    formData.append('max_size', maxSize);

    // Send POST request to the backend
    const base_url = 'http://127.0.0.1:5000';
    fetch(`${base_url}/api/split`, {
      method: 'POST',
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          // Handle successful response

          return response.blob(); // returns a promise, resolved with the value of the body text

        } else {
          // Handle server errors
          alert('An error occurred while splitting the PDF.');
          throw new Error('Server response wasn\'t OK');
        }
      })
      .then((blob) => {
        // Create a link to download the split PDF files as a ZIP
        const url = window.URL.createObjectURL(new Blob([blob]));
        console.log(`Download file url: ${url}`);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'split_pdfs.zip');
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
      })

      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <Container maxWidth="sm" style={{ marginTop: '50px' }}>
      <Typography variant="h4" align="center" gutterBottom>
        PDF Splitter
      </Typography>

      <form onSubmit={handleSubmit}>
        <FormControl fullWidth margin="normal" >
          {/* <InputLabel htmlFor="pdfFile" >Upload PDF File</InputLabel> */}
          <TextField
            id="pdfFile"
            type="file"
            onChange={handleFileChange}

          />
        </FormControl>

        <FormControl fullWidth margin="normal">
          <InputLabel id="max-size-label">Maximum Size per Part (MB)</InputLabel>
          <Select
            labelId="max-size-label"
            id="maxSize"
            value={maxSize}
            label="Maximum Size per Part (MB)"
            onChange={handleMaxSizeChange}
          >
            <MenuItem value={1}>1 MB</MenuItem>
            <MenuItem value={2}>2 MB</MenuItem>
            <MenuItem value={5}>5 MB</MenuItem>
            <MenuItem value={10}>10 MB</MenuItem>
            <MenuItem value={20}>20 MB</MenuItem>
            <MenuItem value={50}>50 MB</MenuItem>
          </Select>
        </FormControl>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          fullWidth
          style={{ marginTop: '20px' }}
        >
          Split PDF
        </Button>
      </form>
    </Container>
  );
}

export default PDFSplitter;

